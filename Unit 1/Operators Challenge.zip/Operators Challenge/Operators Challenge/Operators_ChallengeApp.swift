//
//  Operators_ChallengeApp.swift
//  Operators Challenge
//
//  Created by Tom Bredemeier on 9/2/21.
//

import SwiftUI

@main
struct Operators_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
