//
//  Hello_WorldApp.swift
//  Hello World
//
//  Created by Raphael Abano on 8/23/24.
//

import SwiftUI

@main
struct Hello_WorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
